# Simuladores industriais: Modbus TCP, Modbus RTU, S7 e OPC-UA

Os quatro simuladores representam o mesmo **MCU (STM32) simulado** do `flows.json`.
Eles usam as variáveis `ADC1IN1`, `TEMPSENSOR`, `VREFINT` e `BLUELED` e as mesmas
fórmulas de `voltage1`, `v_ref`, `v_sense` e `temp`. Assim, o mesmo dado chega ao
Node-RED por cinco caminhos diferentes (MQTT + 4 protocolos industriais) e pode ser
comparado no dashboard ou gravado no SQLite.

```
                 ┌──────────────── rede Docker iot-network ─────────────────┐
 modbus-tcp-sim  │ :502   Modbus TCP (MBAP)          ┐                      │
 modbus-rtu-sim  │ :5021  Modbus RTU sobre TCP ──┬───┤                      │
                 │                    socat ─────┘   │                      │
                 │            (/tmp/ttyRTU serial)   ├──► node-red ──► mosquitto
 s7-sim          │ :102   S7comm / ISO-on-TCP        │    telemetry/sim/<proto>
 opcua-sim       │ :4840  OPC-UA (opc.tcp)           ┘                      │
                 └──────────────────────────────────────────────────────────┘
```

| Arquivo | Função |
|---|---|
| `mcu_model.py` | Modelo comum: passeio aleatório suave + fórmulas do STM32 |
| `modbus_sim.py` | Escravo Modbus: `--mode tcp`, `rtu-tcp` ou `serial` (pymodbus) |
| `s7_sim.py` | CLP S7 com DB1, M, I, Q (python-snap7) |
| `opcua_sim.py` | Servidor OPC-UA com objeto `MCU` (asyncua) |
| `testar_clientes.py` | Cliente Python que lê tudo e liga/desliga o LED em cada protocolo |
| `../flows-simuladores.json` | Aba Node-RED com os clientes dos 4 protocolos |

## Como subir

```bash
docker compose up -d --build
docker compose logs -f modbus-tcp-sim modbus-rtu-sim s7-sim opcua-sim
```

No Node-RED (http://localhost:1880): **Menu ☰ → Importar →** selecione
`flows-simuladores.json` → **Deploy**. Aparece a aba **"Simuladores industriais"**.
Cada protocolo publica no MQTT (`telemetry/sim/modbus_tcp`, `.../modbus_rtu`,
`.../modbus_rtu_serial`, `.../s7`, `.../opcua`) o mesmo JSON de
`telemetry/mcu_mock_data`, e tem botões **LED ON/OFF** para testar a escrita.

> Por que importar em vez de editar o `flows.json`? O `/data` do Node-RED fica
> no volume `node-red-data`, que já existe. O `flows.json` copiado na imagem só
> vale na primeira criação do volume.

Teste fora do Node-RED (no host, com Python ≥ 3.10):

```bash
pip install -r simuladores/requirements.txt
python simuladores/testar_clientes.py --host localhost
```

## Mapas de dados

### Modbus (TCP e RTU): ID do escravo 1, endereços base 0

| Tipo | Endereço | Variável | Formato |
|---|---|---|---|
| Coil (FC1/FC5) | 0 | BLUELED | bit, **gravável** |
| Holding (FC3) | 0 | ADC1IN1 | uint16 |
| Holding | 1 | TEMPSENSOR | uint16 |
| Holding | 2 | VREFINT | uint16 |
| Holding | 3 | BLUELED | 0/1, gravável (FC6) |
| Holding | 4–5 | voltage1 | float32 big-endian (ABCD) |
| Holding | 6–7 | v_ref | float32 ABCD |
| Holding | 8–9 | v_sense | float32 ABCD |
| Holding | 10–11 | temp | float32 ABCD |
| Holding | 12 | temp × 100 | int16 (2531 = 25,31 °C) |
| Holding | 13 | heartbeat | uint16 (contador) |
| Input (FC4) | 0–13 | espelho dos holding | somente leitura |

### S7: DB1 (sem "acesso otimizado")

| Endereço S7 | Sintaxe `node-red-contrib-s7` | Tipo | Variável |
|---|---|---|---|
| DB1.DBW0 | `DB1,INT0` | INT | ADC1IN1 |
| DB1.DBW2 | `DB1,INT2` | INT | TEMPSENSOR |
| DB1.DBW4 | `DB1,INT4` | INT | VREFINT |
| DB1.DBX6.0 | `DB1,X6.0` | BOOL | BLUELED (**gravável**) |
| DB1.DBD8 | `DB1,REAL8` | REAL | voltage1 |
| DB1.DBD12 | `DB1,REAL12` | REAL | v_ref |
| DB1.DBD16 | `DB1,REAL16` | REAL | v_sense |
| DB1.DBD20 | `DB1,REAL20` | REAL | temp |
| DB1.DBD24 | `DB1,DINT24` | DINT | heartbeat |

Também existem `Q0.0` (espelho do LED), `IB0` (muda sozinho) e `MB0..MB255`.
Endpoint: `s7-sim:102`, rack 0, slot 1. O simulador aceita qualquer rack/slot.

### OPC-UA: `opc.tcp://opcua-sim:4840/`, segurança None, anônimo

NodeIds `ns=2;s=MCU.<variável>`: `ADC1IN1`, `TEMPSENSOR`, `VREFINT`, `heartbeat`
(Int32); `voltage1`, `v_ref`, `v_sense`, `temp` (Double); `BLUELED` (Boolean, **gravável**).
Namespace URI: `urn:utfpr:mcu-sim`. O índice é 2 e aparece no log do simulador.
Para navegar pela árvore, use o UaExpert ou o nó `OpcUa-Browser`.

## Configuração dos clientes no Node-RED

| Protocolo | Nó de configuração | Parâmetros-chave |
|---|---|---|
| Modbus TCP | `modbus-client` | Type **TCP**, host `modbus-tcp-sim`, port 502, TCP type **DEFAULT**, unit 1 |
| Modbus RTU (sobre TCP) | `modbus-client` | Type **TCP**, host `modbus-rtu-sim`, port 5021, TCP type **TELNET** |
| Modbus RTU (serial) | `modbus-client` | Type **Serial**, port `/tmp/ttyRTU`, RTU-BUFFERD, 9600 8N1, unit 1 |
| S7 | `s7 endpoint` | ISO-on-TCP, `s7-sim`, 102, rack 0, slot 1, ciclo 1000 ms |
| OPC-UA | `OpcUa-Endpoint` | `opc.tcp://opcua-sim:4840/`, None/None, Anonymous |

## Armadilhas (boas para discutir em aula)

1. **"RTU-BUFFERED" no `modbus-client` não é RTU sobre TCP.** Essa opção converte
   para quadros MBAP (Modbus TCP). Para enviar quadros RTU crus (com CRC) por um
   socket, como num gateway serial-Ethernet transparente, use **TELNET**.
2. **Ordem das palavras do float32.** O simulador usa ABCD (big-endian). Muitos
   equipamentos usam CDAB (word swap). Se aparecer um valor absurdo como 1e-38,
   inverta os dois registradores.
3. **Endereço 0 vs 40001.** O endereço 0 no protocolo corresponde ao 40001 na
   notação "Modicon". O Node-RED e o pymodbus usam o endereço do protocolo (0).
4. **S7-1200/1500 reais** exigem *PUT/GET* habilitado e o DB com *Optimized block
   access* desligado. No S7-300 o slot é 2.
5. **Índice de namespace OPC-UA** pode mudar entre servidores. Em código robusto,
   resolva pelo URI (`get_namespace_index`) em vez de fixar `ns=2`.
6. **Porta 102** abaixo de 1024: fora do Docker no Linux, rode
   `python s7_sim.py --port 1102` (sem root) e ajuste o cliente.

## Modbus RTU em porta serial "de verdade"

O RTU usa uma **porta serial virtual** porque containers não compartilham
pseudo-terminais. O `nodered-start.sh` executa `socat` dentro do container do
Node-RED e cria `/tmp/ttyRTU` ligado ao `modbus-rtu-sim:5021`. Para o Node-RED,
ela é uma serial comum.

Outras formas:

- **Linux, sem Docker**, par de portas virtuais:
  ```bash
  socat -d -d pty,raw,echo=0,link=/tmp/ttyV0 pty,raw,echo=0,link=/tmp/ttyV1
  python modbus_sim.py --mode serial --serial-port /tmp/ttyV0 --baudrate 9600
  # cliente (Node-RED, mbpoll, QModMaster...) em /tmp/ttyV1
  ```
- **Windows**: crie um par COM com o **com0com** (ex.: COM10↔COM11) e rode
  `python modbus_sim.py --mode serial --serial-port COM10`.
- **Hardware real**: dois adaptadores USB-RS485 (A↔A, B↔B). O simulador fica num
  PC e o cliente em outro. Para o container do Node-RED, mapeie `devices:` no
  `docker-compose.yml`.

## Rodar sem Docker

```bash
pip install -r requirements.txt
python modbus_sim.py --mode tcp --port 5020
python modbus_sim.py --mode rtu-tcp --port 5021
python s7_sim.py --port 1102
python opcua_sim.py --hostname localhost
```

Todas as opções aparecem com `--help`, entre elas `--period`, `--unit`, `--baudrate`,
`--parity` e `--stopbits`.

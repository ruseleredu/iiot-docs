
## Updated Dockerfile

To completely reset and rebuild everything from absolute scratch (wipes out old build cache):

```bash
docker compose build --no-cache
```

Rebuild the Node-RED image and recreate the container:

```bash
docker compose up -d --build
```

## Dashboard

For [FlowFuse Dashboard](https://dashboard.flowfuse.com/):
- http://localhost:1880/dashboard/camara

MQTT Explorer: http://localhost:1881

## Câmara Climática com ESP32 (simulada)

O serviço `camara-sim` simula uma câmara climática com ESP32, DHT22, OLED, potenciômetro
(ADC) e aquecedor e ventilador por PWM. Ele publica e recebe comandos via **MQTT 5
(paho-mqtt)** no `mosquitto` e também atende **Modbus TCP/RTU, S7 e OPC-UA**.
Detalhes: [simuladores/README.md](simuladores/README.md).

| Acesso | Endereço |
|---|---|
| Dashboard da câmara | http://localhost:1880/dashboard/camara |
| MQTT | `camara/esp32-01/telemetria`, `.../cmd`, `.../cmd/<campo>`, `.../status`, `.../oled` |
| Modbus TCP / RTU sobre TCP | `localhost:5020` / `localhost:5021` (na rede Docker: `camara-sim:502` / `:5021`) |
| Siemens S7 | `localhost:102`, rack 0, slot 1 |
| OPC-UA | `opc.tcp://localhost:4840/` (`ns=2;s=Camara.*`) |

### Carregar os novos fluxos

O `/data` do Node-RED fica no volume `node-red-data`. Se ele já existe, o `flows.json`
da imagem é ignorado. Escolha uma das opções:

- **Importar:** Node-RED → Menu ☰ → Importar → `flows.json` → *Substituir* os nós existentes → Deploy.
- **Recomeçar do zero** (apaga os fluxos e o banco antigos do volume):
  ```bash
  docker compose down
  docker volume rm esp32-iot_node-red-data
  docker compose up -d --build
  ```

Os fluxos antigos do "MCU mock" estão em `legado/`.

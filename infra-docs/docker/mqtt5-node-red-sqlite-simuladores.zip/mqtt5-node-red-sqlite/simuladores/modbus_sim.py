"""
Simulador Modbus (escravo/servidor) - TCP e RTU.

Modos:
  --mode tcp      Modbus TCP (MBAP), porta padrão 502
  --mode rtu-tcp  Modbus RTU "encapsulado" em TCP (quadros RTU com CRC sobre
                  um socket TCP), como fazem os gateways serial-Ethernet.
                  É a forma mais simples de usar RTU dentro do Docker.
  --mode serial   Modbus RTU numa porta serial real ou virtual
                  (/dev/ttyUSB0, /dev/pts/N criado com socat, COM3 com com0com...)

Mapa de registradores (endereços base 0, ID do escravo = 1 por padrão):

  Coils (FC1 leitura, FC5/FC15 escrita)
    0      BLUELED (escrita liga/desliga o LED simulado)

  Holding registers (FC3 leitura; FC6/FC16 escrita apenas no reg. 3)
    0      ADC1IN1          uint16
    1      TEMPSENSOR       uint16
    2      VREFINT          uint16
    3      BLUELED          uint16 (0/1, gravável)
    4-5    voltage1         float32 big-endian (ABCD)
    6-7    v_ref            float32 ABCD
    8-9    v_sense          float32 ABCD
    10-11  temp             float32 ABCD
    12     temp x 100       int16 (ex.: 2531 = 25,31 °C)
    13     heartbeat        uint16 (contador)

  Input registers (FC4): espelho somente-leitura dos holding 0..13.
"""

import argparse
import asyncio
import struct

from pymodbus import FramerType
from pymodbus.datastore import (
    ModbusSequentialDataBlock,
    ModbusServerContext,
    ModbusSlaveContext,
)
from pymodbus.device import ModbusDeviceIdentification
from pymodbus.server import StartAsyncSerialServer, StartAsyncTcpServer

from mcu_model import MCUModel, log

FC_COILS, FC_HR, FC_IR = 1, 3, 4
N_REGS = 14


def f32_to_regs(value):
    """float32 -> 2 registradores, ordem big-endian (ABCD)."""
    hi, lo = struct.unpack(">HH", struct.pack(">f", value))
    return [hi, lo]


def build_registers(s):
    regs = [s["ADC1IN1"], s["TEMPSENSOR"], s["VREFINT"], s["BLUELED"]]
    for key in ("voltage1", "v_ref", "v_sense", "temp"):
        regs += f32_to_regs(s[key])
    regs.append(struct.unpack(">H", struct.pack(">h", int(round(s["temp"] * 100))))[0])
    regs.append(s["heartbeat"])
    return regs


async def updater(model, context, unit, period):
    dev = context[unit]
    last_coil, last_hr3 = 0, 0
    while True:
        # 1) Aplica escritas feitas pelo cliente (coil 0 ou HR 3)
        coil = int(dev.getValues(FC_COILS, 0, 1)[0])
        hr3 = int(dev.getValues(FC_HR, 3, 1)[0])
        if coil != last_coil:
            model.set_led(coil)
            log("modbus", f"cliente escreveu coil 0 = {coil}")
        elif hr3 != last_hr3:
            model.set_led(hr3)
            log("modbus", f"cliente escreveu HR 3 = {hr3}")

        # 2) Avança a simulação e publica nos registradores
        model.step()
        s = model.snapshot()
        regs = build_registers(s)
        dev.setValues(FC_HR, 0, regs)
        dev.setValues(FC_IR, 0, regs)
        dev.setValues(FC_COILS, 0, [bool(s["BLUELED"])])
        last_coil, last_hr3 = s["BLUELED"], s["BLUELED"]
        await asyncio.sleep(period)


async def main():
    p = argparse.ArgumentParser(description="Simulador Modbus TCP/RTU")
    p.add_argument("--mode", choices=["tcp", "rtu-tcp", "serial"], default="tcp")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=502)
    p.add_argument("--serial-port", default="/dev/ttyUSB0")
    p.add_argument("--baudrate", type=int, default=9600)
    p.add_argument("--parity", default="N", choices=["N", "E", "O"])
    p.add_argument("--stopbits", type=int, default=1)
    p.add_argument("--unit", type=int, default=1, help="ID do escravo (unit id)")
    p.add_argument("--period", type=float, default=1.0, help="s entre atualizações")
    a = p.parse_args()

    device = ModbusSlaveContext(
        co=ModbusSequentialDataBlock(0, [False] * 16),
        di=ModbusSequentialDataBlock(0, [False] * 16),
        hr=ModbusSequentialDataBlock(0, [0] * 32),
        ir=ModbusSequentialDataBlock(0, [0] * 32),
    )
    context = ModbusServerContext(slaves={a.unit: device}, single=False)

    identity = ModbusDeviceIdentification(
        info_name={
            "VendorName": "UTFPR",
            "ProductCode": "MCU-SIM",
            "ProductName": "Simulador MCU Modbus",
            "ModelName": a.mode,
            "MajorMinorRevision": "1.0",
        }
    )

    model = MCUModel()
    asyncio.create_task(updater(model, context, a.unit, a.period))

    if a.mode == "serial":
        log("modbus", f"RTU serial em {a.serial_port} {a.baudrate} 8{a.parity}{a.stopbits}, unit {a.unit}")
        await StartAsyncSerialServer(
            context=context, identity=identity, framer=FramerType.RTU,
            port=a.serial_port, baudrate=a.baudrate, parity=a.parity,
            stopbits=a.stopbits, bytesize=8,
        )
    else:
        framer = FramerType.SOCKET if a.mode == "tcp" else FramerType.RTU
        log("modbus", f"{a.mode} em {a.host}:{a.port}, unit {a.unit}")
        await StartAsyncTcpServer(
            context=context, identity=identity, framer=framer,
            address=(a.host, a.port),
        )


if __name__ == "__main__":
    asyncio.run(main())

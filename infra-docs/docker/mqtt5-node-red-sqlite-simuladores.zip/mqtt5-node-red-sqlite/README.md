
## Updated Dockerfile

To completely reset and rebuild everything from absolute scratch (wipes out old build cache):

```bash
docker compose build --no-cache
```

Rebuild the Node-RED image and recreate the container:

```bash
docker compose up -d --build
```

## Dashboard

For [FlowFuse Dashboard](https://dashboard.flowfuse.com/):
- http://localhost:1881/dashboard
  
For [node-red-dashboard](https://flows.nodered.org/node/node-red-dashboard):
- http://localhost:1881/ui

## Simuladores industriais (Modbus TCP, Modbus RTU, S7, OPC-UA)

Os serviços `modbus-tcp-sim`, `modbus-rtu-sim`, `s7-sim` e `opcua-sim` sobem junto com o
`docker compose up -d --build`. Importe `flows-simuladores.json` no Node-RED
(Menu → Importar) para ter os clientes prontos. Detalhes, mapas de registradores e
armadilhas: [simuladores/README.md](simuladores/README.md).

| Simulador | Porta no host | Endereço dentro da rede Docker |
|---|---|---|
| Modbus TCP | 5020 | `modbus-tcp-sim:502` |
| Modbus RTU (sobre TCP) | 5021 | `modbus-rtu-sim:5021` (serial virtual `/tmp/ttyRTU` no Node-RED) |
| Siemens S7 | 102 | `s7-sim:102` (rack 0, slot 1) |
| OPC-UA | 4840 | `opc.tcp://opcua-sim:4840/` |

"""
Modelo compartilhado do "MCU simulado" (STM32) usado por todos os simuladores.

Usa as MESMAS variáveis e fórmulas do nó "JSON mcu_mock_data" do flows.json,
para que os dados vindos de Modbus TCP, Modbus RTU, S7 e OPC-UA sejam
comparáveis com os dados já publicados via MQTT e gravados no SQLite.

Diferença em relação ao mock do Node-RED: em vez de valores totalmente
aleatórios a cada amostra, aqui as grandezas fazem um "passeio aleatório"
suave dentro da faixa, o que deixa os gráficos do dashboard mais realistas.
"""

import random
import threading
import time

V_AT_25C = 0.76      # V a 25 °C
AVG_SLOPE = 0.0025   # 2,5 mV/°C em V/°C


def _walk(value, step, lo, hi):
    """Passeio aleatório limitado à faixa [lo, hi]."""
    value += random.randint(-step, step)
    return max(lo, min(hi, value))


class MCUModel:
    def __init__(self):
        self._lock = threading.Lock()
        self.ADC1IN1 = 2048       # 12 bits, 1500..2600
        self.TEMPSENSOR = 1045    # 950..1100 (~25 °C)
        self.VREFINT = 1650       # 1600..1700
        self.BLUELED = 0          # 0/1 - pode ser escrito pelos clientes
        self.heartbeat = 0        # contador incrementado a cada atualização
        self._derive()

    def _derive(self):
        self.v_ref = (1.21 * 4095) / self.VREFINT
        self.voltage1 = (self.ADC1IN1 * self.v_ref) / 4095
        self.v_sense = (self.TEMPSENSOR * self.v_ref) / 4095
        self.temp = ((self.v_sense - V_AT_25C) / AVG_SLOPE) + 25.0

    def step(self):
        with self._lock:
            self.ADC1IN1 = _walk(self.ADC1IN1, 40, 1500, 2600)
            self.TEMPSENSOR = _walk(self.TEMPSENSOR, 3, 950, 1100)
            self.VREFINT = _walk(self.VREFINT, 2, 1600, 1700)
            self.heartbeat = (self.heartbeat + 1) & 0xFFFF
            self._derive()

    def set_led(self, value):
        with self._lock:
            self.BLUELED = 1 if value else 0

    def snapshot(self):
        with self._lock:
            return {
                "ADC1IN1": self.ADC1IN1,
                "voltage1": round(self.voltage1, 4),
                "BLUELED": self.BLUELED,
                "TEMPSENSOR": self.TEMPSENSOR,
                "v_ref": round(self.v_ref, 4),
                "v_sense": round(self.v_sense, 4),
                "temp": round(self.temp, 2),
                "VREFINT": self.VREFINT,
                "heartbeat": self.heartbeat,
            }


def log(proto, msg):
    print(f"[{time.strftime('%H:%M:%S')}] [{proto}] {msg}", flush=True)

"""
Simulador de CLP Siemens S7 (protocolo S7comm / ISO-on-TCP, porta 102).

Usa o servidor do python-snap7. Aceita qualquer rack/slot
(no CLP real: rack 0 / slot 2 para S7-300; rack 0 / slot 1 para S7-1200/1500).

Data Block DB1 (big-endian, como no CLP real):

  Endereço S7      nodes7 (node-red-contrib-s7)   Tipo   Variável
  DB1.DBW0         DB1,INT0                        INT    ADC1IN1
  DB1.DBW2         DB1,INT2                        INT    TEMPSENSOR
  DB1.DBW4         DB1,INT4                        INT    VREFINT
  DB1.DBX6.0       DB1,X6.0                        BOOL   BLUELED (gravável)
  DB1.DBD8         DB1,REAL8                       REAL   voltage1
  DB1.DBD12        DB1,REAL12                      REAL   v_ref
  DB1.DBD16        DB1,REAL16                      REAL   v_sense
  DB1.DBD20        DB1,REAL20                      REAL   temp
  DB1.DBD24        DB1,DINT24                      DINT   heartbeat

Também expõe áreas de memória M (marcadores), I (entradas) e Q (saídas):
  MB0..MB255, IB0..IB31, QB0..QB31 - Q0.0 espelha o BLUELED.

Obs.: em CLPs S7-1200/1500 reais o DB precisa ter "Optimized block access"
desligado e "PUT/GET" habilitado para esse tipo de acesso funcionar.
"""

import argparse
import struct
import time

import snap7
from snap7.type import SrvArea

from mcu_model import MCUModel, log

DB_SIZE = 32


def main():
    p = argparse.ArgumentParser(description="Simulador Siemens S7")
    p.add_argument("--port", type=int, default=102)
    p.add_argument("--period", type=float, default=1.0)
    a = p.parse_args()

    db1 = bytearray(DB_SIZE)
    mk = bytearray(256)
    pe = bytearray(32)   # entradas  (I)
    pa = bytearray(32)   # saídas    (Q)

    server = snap7.server.Server(log=False)
    server.register_area(SrvArea.DB, 1, db1)
    server.register_area(SrvArea.MK, 0, mk)
    server.register_area(SrvArea.PE, 0, pe)
    server.register_area(SrvArea.PA, 0, pa)
    server.start(tcp_port=a.port)
    log("s7", f"servidor S7 na porta {a.port} (DB1, M, I, Q)")

    model = MCUModel()
    last_led = 0
    try:
        while True:
            server.lock_area(SrvArea.DB, 1)
            try:
                # Escrita do cliente em DB1.DBX6.0 controla o LED
                led = db1[6] & 0x01
                if led != last_led:
                    model.set_led(led)
                    log("s7", f"cliente escreveu DB1.DBX6.0 = {led}")

                model.step()
                s = model.snapshot()
                struct.pack_into(">hhh", db1, 0, s["ADC1IN1"], s["TEMPSENSOR"], s["VREFINT"])
                db1[6] = (db1[6] & 0xFE) | s["BLUELED"]
                struct.pack_into(">ffff", db1, 8, s["voltage1"], s["v_ref"], s["v_sense"], s["temp"])
                struct.pack_into(">i", db1, 24, s["heartbeat"])
                last_led = s["BLUELED"]
            finally:
                server.unlock_area(SrvArea.DB, 1)

            pa[0] = (pa[0] & 0xFE) | s["BLUELED"]   # Q0.0
            pe[0] = s["heartbeat"] & 0xFF           # IB0 muda sozinho
            time.sleep(a.period)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
        server.destroy()


if __name__ == "__main__":
    main()

"""
Cliente de teste: lê (e escreve o LED) em todos os simuladores.

Uso (fora do Docker, com as portas publicadas pelo docker-compose):
    python testar_clientes.py --host localhost
"""

import argparse
import asyncio
import struct

from asyncua import Client, ua
from pymodbus import FramerType
from pymodbus.client import AsyncModbusTcpClient
import snap7


def regs_to_f32(hi, lo):
    return struct.unpack(">f", struct.pack(">HH", hi, lo))[0]


async def test_modbus(host, port, framer, label):
    c = AsyncModbusTcpClient(host, port=port, framer=framer, timeout=3)
    await c.connect()
    await c.write_coil(0, True, slave=1)
    await asyncio.sleep(1.5)
    rr = await c.read_holding_registers(0, count=14, slave=1)
    r = rr.registers
    print(f"[{label}] ADC1IN1={r[0]} TEMPSENSOR={r[1]} VREFINT={r[2]} BLUELED={r[3]} "
          f"voltage1={regs_to_f32(r[4], r[5]):.4f} temp={regs_to_f32(r[10], r[11]):.2f} "
          f"temp_x100={r[12]} heartbeat={r[13]}")
    await c.write_coil(0, False, slave=1)
    c.close()


def test_s7(host, port):
    c = snap7.client.Client()
    c.connect(host, 0, 1, port)
    c.db_write(1, 6, bytearray([1]))          # DB1.DBX6.0 = 1
    import time; time.sleep(1.5)
    d = c.db_read(1, 0, 28)
    adc, ts, vr = struct.unpack_from(">hhh", d, 0)
    v1, vref, vs, t = struct.unpack_from(">ffff", d, 8)
    hb = struct.unpack_from(">i", d, 24)[0]
    print(f"[S7] ADC1IN1={adc} TEMPSENSOR={ts} VREFINT={vr} BLUELED={d[6] & 1} "
          f"voltage1={v1:.4f} temp={t:.2f} heartbeat={hb}")
    c.db_write(1, 6, bytearray([0]))
    c.disconnect()


async def test_opcua(host, port):
    async with Client(f"opc.tcp://{host}:{port}/") as c:
        idx = await c.get_namespace_index("urn:utfpr:mcu-sim")
        led = c.get_node(f"ns={idx};s=MCU.BLUELED")
        await led.write_value(ua.DataValue(ua.Variant(True, ua.VariantType.Boolean)))
        await asyncio.sleep(1.5)
        vals = {}
        for n in ("ADC1IN1", "TEMPSENSOR", "VREFINT", "voltage1", "temp", "heartbeat"):
            vals[n] = await c.get_node(f"ns={idx};s=MCU.{n}").read_value()
        vals["BLUELED"] = await led.read_value()
        print(f"[OPC-UA ns={idx}] " + " ".join(f"{k}={v:.4g}" if isinstance(v, float) else f"{k}={v}"
                                               for k, v in vals.items()))
        await led.write_value(ua.DataValue(ua.Variant(False, ua.VariantType.Boolean)))


async def main():
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="localhost")
    p.add_argument("--modbus-tcp-port", type=int, default=5020)
    p.add_argument("--modbus-rtu-port", type=int, default=5021)
    p.add_argument("--s7-port", type=int, default=102)
    p.add_argument("--opcua-port", type=int, default=4840)
    a = p.parse_args()

    for name, coro in [
        ("Modbus TCP", test_modbus(a.host, a.modbus_tcp_port, FramerType.SOCKET, "Modbus TCP")),
        ("Modbus RTU", test_modbus(a.host, a.modbus_rtu_port, FramerType.RTU, "Modbus RTU-over-TCP")),
        ("S7", asyncio.to_thread(test_s7, a.host, a.s7_port)),
        ("OPC-UA", test_opcua(a.host, a.opcua_port)),
    ]:
        try:
            await coro
        except Exception as e:  # noqa: BLE001
            print(f"[{name}] FALHOU: {e!r}")


if __name__ == "__main__":
    asyncio.run(main())

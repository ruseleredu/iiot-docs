"""
Simulador da Câmara Climática com ESP32 (DHT22, OLED, potenciômetro, PWM).

Uma única planta é exposta ao mesmo tempo por MQTT (paho-mqtt), Modbus TCP,
Modbus RTU (sobre TCP e/ou serial), Siemens S7 e OPC-UA. Um comando enviado por
qualquer protocolo (ex.: setpoint via OPC-UA) aparece em todos os outros.

Exemplos:
  python camara_sim.py                                  # tudo nas portas padrão
  python camara_sim.py --mqtt-host localhost --s7-port 1102 --modbus-tcp-port 5020
  python camara_sim.py --speed 10                       # dinâmica 10x mais rápida
  python camara_sim.py --no-s7 --no-opcua --modbus-serial /dev/ttyUSB0

Variáveis de ambiente equivalentes: MQTT_HOST, MQTT_PORT, MQTT_BASE, MQTT_USER,
MQTT_PASS, SIM_SPEED.
"""

import argparse
import asyncio
import os
import signal
import time

from camara_model import Camara


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def args():
    e = os.environ.get
    p = argparse.ArgumentParser(description="Simulador Câmara Climática ESP32")
    p.add_argument("--speed", type=float, default=float(e("SIM_SPEED", "1")),
                   help="fator de aceleração da dinâmica (1 = tempo real)")
    p.add_argument("--host", default="0.0.0.0", help="interface dos servidores")
    # MQTT
    p.add_argument("--mqtt-host", default=e("MQTT_HOST", "localhost"))
    p.add_argument("--mqtt-port", type=int, default=int(e("MQTT_PORT", "1883")))
    p.add_argument("--mqtt-base", default=e("MQTT_BASE", "camara/esp32-01"))
    p.add_argument("--mqtt-user", default=e("MQTT_USER"))
    p.add_argument("--mqtt-pass", default=e("MQTT_PASS"))
    p.add_argument("--mqtt-period", type=float, default=2.0)
    p.add_argument("--mqtt-v311", action="store_true", help="usar MQTT 3.1.1 em vez de 5")
    p.add_argument("--no-mqtt", action="store_true")
    # Modbus
    p.add_argument("--modbus-tcp-port", type=int, default=502)
    p.add_argument("--modbus-rtu-port", type=int, default=5021, help="RTU sobre TCP (0 desliga)")
    p.add_argument("--modbus-serial", default=None, help="porta serial RTU, ex. /dev/ttyUSB0")
    p.add_argument("--baudrate", type=int, default=9600)
    p.add_argument("--parity", default="N", choices=["N", "E", "O"])
    p.add_argument("--no-modbus", action="store_true")
    # S7 / OPC-UA
    p.add_argument("--s7-port", type=int, default=102)
    p.add_argument("--no-s7", action="store_true")
    p.add_argument("--opcua-port", type=int, default=4840)
    p.add_argument("--opcua-hostname", default="0.0.0.0", help="nome anunciado no endpoint")
    p.add_argument("--no-opcua", action="store_true")
    return p.parse_args()


async def main():
    a = args()
    cam = Camara(speed=a.speed, log=log)
    log(f"[planta] câmara climática simulada, speed={a.speed}x")

    modbus = s7 = opcua = mq = None
    tasks = []
    if not a.no_modbus:
        from proto_modbus import ModbusAdapter
        modbus = ModbusAdapter(cam, log)
        tasks.append(asyncio.create_task(modbus.start(
            a.host, a.modbus_tcp_port, a.modbus_rtu_port, a.modbus_serial, a.baudrate, a.parity)))
    if not a.no_s7:
        from proto_s7 import S7Adapter
        s7 = S7Adapter(cam, log)
        s7.start(a.s7_port)
    if not a.no_opcua:
        from proto_opcua import OpcUaAdapter
        opcua = OpcUaAdapter(cam, log)
        await opcua.start(a.opcua_hostname, a.opcua_port)
    if not a.no_mqtt:
        from proto_mqtt import MqttAdapter
        mq = MqttAdapter(cam, log, a.mqtt_host, a.mqtt_port, a.mqtt_base,
                         a.mqtt_user, a.mqtt_pass, v5=not a.mqtt_v311)
        mq.start()

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:      # Windows
            pass

    DT = 0.1
    n = 0
    t_mqtt = 0.0
    last = time.monotonic()
    try:
        while not stop.is_set():
            now = time.monotonic()
            cam.step(now - last)
            last = now
            n += 1
            if n % 5 == 0:                       # sincroniza protocolos a cada 0,5 s
                s = cam.snapshot()
                if modbus:
                    modbus.sync(s)
                if s7:
                    s7.sync(s)
                if opcua:
                    await opcua.sync(s)
            t_mqtt += DT
            if mq and t_mqtt >= a.mqtt_period:
                t_mqtt = 0.0
                mq.publish(cam.snapshot())
            for t in tasks:
                if t.done() and t.exception():
                    raise t.exception()
            try:
                await asyncio.wait_for(stop.wait(), DT)
            except asyncio.TimeoutError:
                pass
    finally:
        log("[planta] encerrando")
        if mq:
            mq.stop()
        if s7:
            s7.stop()
        if opcua:
            await opcua.stop()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass

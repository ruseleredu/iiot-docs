"""
Simulador de servidor OPC-UA (asyncua), porta 4840.

Endpoint:   opc.tcp://<host>:4840/
Segurança:  None / acesso anônimo (apenas para laboratório!)

Espaço de endereços (NodeIds em string no namespace ns=2):

  Objects/
    MCU/
      ADC1IN1     ns=2;s=MCU.ADC1IN1     Int32
      TEMPSENSOR  ns=2;s=MCU.TEMPSENSOR  Int32
      VREFINT     ns=2;s=MCU.VREFINT     Int32
      voltage1    ns=2;s=MCU.voltage1    Double
      v_ref       ns=2;s=MCU.v_ref       Double
      v_sense     ns=2;s=MCU.v_sense     Double
      temp        ns=2;s=MCU.temp        Double
      heartbeat   ns=2;s=MCU.heartbeat   Int32
      BLUELED     ns=2;s=MCU.BLUELED     Boolean (gravável)

Obs.: o namespace URI é "urn:utfpr:mcu-sim". Ele é o primeiro namespace
registrado, por isso o índice fica 2; o simulador confirma no log.
"""

import argparse
import asyncio
import logging

from asyncua import Server, ua

from mcu_model import MCUModel, log

NS_URI = "urn:utfpr:mcu-sim"

VARS = [
    ("ADC1IN1", ua.VariantType.Int32),
    ("TEMPSENSOR", ua.VariantType.Int32),
    ("VREFINT", ua.VariantType.Int32),
    ("voltage1", ua.VariantType.Double),
    ("v_ref", ua.VariantType.Double),
    ("v_sense", ua.VariantType.Double),
    ("temp", ua.VariantType.Double),
    ("heartbeat", ua.VariantType.Int32),
]


async def main():
    p = argparse.ArgumentParser(description="Simulador OPC-UA")
    p.add_argument("--port", type=int, default=4840)
    p.add_argument("--hostname", default="0.0.0.0",
                   help="nome anunciado no endpoint (use o nome do serviço no Docker)")
    p.add_argument("--period", type=float, default=1.0)
    a = p.parse_args()
    logging.basicConfig(level=logging.WARNING)

    server = Server()
    await server.init()
    server.set_endpoint(f"opc.tcp://{a.hostname}:{a.port}/")
    server.set_server_name("UTFPR MCU Simulator")
    server.set_security_policy([ua.SecurityPolicyType.NoSecurity])

    idx = await server.register_namespace(NS_URI)
    mcu = await server.nodes.objects.add_object(ua.NodeId("MCU", idx), f"{idx}:MCU")

    model = MCUModel()
    snap = model.snapshot()
    nodes = {}
    for name, vtype in VARS:
        nodes[name] = await mcu.add_variable(
            ua.NodeId(f"MCU.{name}", idx), f"{idx}:{name}",
            ua.Variant(snap[name], vtype),
        )
    led = await mcu.add_variable(
        ua.NodeId("MCU.BLUELED", idx), f"{idx}:BLUELED",
        ua.Variant(False, ua.VariantType.Boolean),
    )
    await led.set_writable()

    async with server:
        log("opcua", f"servidor em opc.tcp://{a.hostname}:{a.port}/  namespace '{NS_URI}' = ns={idx}")
        while True:
            # Valor escrito pelo cliente no BLUELED controla o modelo
            model.set_led(await led.read_value())
            model.step()
            s = model.snapshot()
            for name, vtype in VARS:
                await nodes[name].write_value(ua.Variant(s[name], vtype))
            await asyncio.sleep(a.period)


if __name__ == "__main__":
    asyncio.run(main())

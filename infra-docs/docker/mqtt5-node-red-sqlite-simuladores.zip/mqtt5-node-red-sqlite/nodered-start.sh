#!/bin/sh
# Inicialização do Node-RED com "porta serial virtual" para o Modbus RTU.
#
# Se RTU_SERIAL_BRIDGE estiver definido (ex.: modbus-rtu-sim:5021), o socat
# cria o pseudo-terminal /tmp/ttyRTU ligado ao simulador RTU via TCP.
# Para o Node-RED, /tmp/ttyRTU é uma porta serial comum (cliente Modbus
# "Serial", RTU-BUFFERD, 9600 8N1).
if [ -n "$RTU_SERIAL_BRIDGE" ]; then
  (
    while true; do
      socat pty,link=/tmp/ttyRTU,raw,echo=0,mode=660 "tcp:${RTU_SERIAL_BRIDGE}" 2>/dev/null
      sleep 3   # simulador ainda não subiu ou conexão caiu: tenta de novo
    done
  ) &
fi

# Entrypoint original da imagem nodered/node-red
exec ./entrypoint.sh "$@"

# Câmara Climática com ESP32: simulador e protocolos

O `camara_sim.py` simula **uma** câmara climática controlada por um ESP32. Inclui a planta
térmica e de umidade e o firmware. A mesma câmara fica disponível ao mesmo tempo por:

| Protocolo | Biblioteca | Porta (container) | Papel |
|---|---|---|---|
| **MQTT 5** | paho-mqtt 2.1 | cliente de `mosquitto:1883` | o que o ESP32 real faz (telemetria + comandos) |
| Modbus TCP | pymodbus 3.9.2 | 502 (host 5020) | escravo, unit id 1 |
| Modbus RTU | pymodbus | 5021 (RTU sobre TCP) / serial | escravo, unit id 1 |
| Siemens S7 | python-snap7 | 102 | "CLP" com DB1 e imagem de processo |
| OPC-UA | asyncua | 4840 | servidor `opc.tcp://camara-sim:4840/` |

Um comando enviado por qualquer protocolo aparece em todos os outros. Por exemplo, um
setpoint escrito via OPC-UA aparece no Modbus, no S7, no MQTT e no dashboard.

## 1. Objetivos atendidos

| Objetivo | Como foi implementado |
|---|---|
| Medir temperatura | DHT22 simulado: resolução 0,1 °C, ruído ±0,1 °C, leitura a cada 2 s |
| Medir umidade relativa | DHT22 simulado: ruído ±0,5 %UR, calculada da umidade absoluta (Magnus) |
| Configurar o setpoint | `setpoint` remoto (MQTT/Modbus/S7/OPC-UA/dashboard), faixa 20–55 °C |
| Aquecedor por PWM | `aquecedor_pwm` 0–100 % → LEDC 8 bits (`aquecedor_duty` 0–255) |
| Ventilador por PWM | `ventilador_pwm` 0–100 % → LEDC 8 bits (`ventilador_duty` 0–255) |
| Tela OLED | 6 linhas × 21 caracteres (SSD1306 128×64), em `oled` e `camara/esp32-01/oled` |
| Potenciômetro (ADC) | `pot_raw` 0–4095 (12 bits, ruído ±3); com `fonte_sp = 1` vira o setpoint |
| Estratégia de controle | Modos internos ON/OFF e PI, ou MANUAL para um controlador externo (aba Node-RED) |
| Sinalizar o estado | `estado` (0–4), LEDs verde/amarelo/vermelho, `alarme`, status MQTT online/offline |

## 2. Hardware representado (pinagem sugerida para montar a câmara real)

| Componente | ESP32 | Observação |
|---|---|---|
| DHT22 | GPIO4 | pull-up 10 kΩ, leitura ≥ 2 s |
| Potenciômetro 10 kΩ | GPIO34 (ADC1_CH6) | ADC 12 bits, atenuação 11 dB |
| Aquecedor (resistência ~25 W) | GPIO25 → MOSFET logic-level | LEDC 8 bits (pode usar frequência baixa, ex. 10 Hz) |
| Ventilador 12 V | GPIO26 → MOSFET | LEDC 8 bits, 25 kHz |
| OLED SSD1306 128×64 | SDA GPIO21 / SCL GPIO22 | I²C 0x3C |
| LED verde / amarelo / vermelho | GPIO16 / GPIO17 / GPIO5 | 330 Ω |

## 3. Modelo da planta

```
C_h·dTh/dt = P − k_hc·(Th − Tc)                  resistência (atraso térmico)
C_c·dTc/dt = k_hc·(Th − Tc) − k_loss·(Tc − Tamb)  ar + paredes
dAH/dt     = S + k_v·(AH_amb − AH)                umidade absoluta (g/m³)
UR         = AH / AH_sat(Tc)                      → aquecer REDUZ a umidade relativa
```

Parâmetros: P até 25 W, C_h = 20 J/K, C_c = 120 J/K e ambiente a 25 °C / 60 %UR.
O ventilador aumenta k_hc, k_loss e k_v, ou seja, mistura melhor o ar e troca mais com o ambiente.
Em tempo real (`SIM_SPEED=1`), a câmara vai de 25 °C a 35 °C em cerca de 1,5 min. Use
`SIM_SPEED=5` ou `10` para aulas curtas.

## 4. Firmware simulado: controle, proteções e estados

| `modo` | Aquecedor | Ventilador |
|---|---|---|
| 0 MANUAL | `aquecedor_cmd` | `ventilador_cmd` |
| 1 ON/OFF | 100 % se T < SP − 0,5; 0 % se T > SP + 0,5 | 100 % se T > SP + 2, senão 20 % |
| 2 PI | Kp = 15 %/°C, Ki = 0,15 %/(°C·s), anti-windup | 20 % + resfriamento proporcional se T > SP |

- **Proteções:** com T ≥ 60 °C ou falha do DHT22 (3 leituras seguidas com erro), o estado vai
  para **ALARME**. O aquecedor vai a 0 % e o ventilador a 100 %. O alarme é liberado quando
  T < 55 °C e o sensor está OK.
- **`estado`:** 0 DESLIGADO · 1 AQUECENDO (e > 1 °C) · 2 RESFRIANDO (e < −1 °C) ·
  3 ESTAVEL (|e| ≤ 1 °C) · 4 ALARME, com e = SP − T.
- **LEDs:** verde = ESTAVEL, amarelo = AQUECENDO/RESFRIANDO, vermelho = ALARME.
- **`alarme`** (bits): 1 = sobretemperatura, 2 = falha do sensor.
- **Simulação de bancada:** `pot_raw` "gira o potenciômetro" e `falha_dht` desconecta o sensor.

## 5. MQTT (contrato do ESP32)

Base: `camara/esp32-01` (variável `MQTT_BASE`).

| Tópico | Direção | Conteúdo |
|---|---|---|
| `…/status` | ESP32 → | `online` / `offline` (retido; `offline` é o *Last Will*) |
| `…/telemetria` | ESP32 → | JSON a cada 2 s (exemplo abaixo) |
| `…/oled` | ESP32 → | texto da tela (6 linhas) |
| `…/cmd` | → ESP32 | JSON parcial: `{"setpoint": 40, "modo": 2}` |
| `…/cmd/<campo>` | → ESP32 | valor simples: `…/cmd/setpoint` ← `40` |

Campos de comando: `habilitado`, `modo`, `fonte_sp`, `setpoint`, `aquecedor_cmd`,
`ventilador_cmd`, `pot_raw` (sim.) e `falha_dht` (sim.). Valores fora da faixa são saturados.

```json
{"temp": 35.1, "umid": 38.4, "pot_raw": 1756, "sp_efetivo": 35.0,
 "aquecedor_pwm": 29.0, "ventilador_pwm": 20.0, "aquecedor_duty": 74, "ventilador_duty": 51,
 "habilitado": 1, "modo": 2, "modo_txt": "PI", "fonte_sp": 0, "setpoint": 35.0,
 "aquecedor_cmd": 0.0, "ventilador_cmd": 20.0, "falha_dht": 0, "pot_sim": 1755,
 "estado": 3, "estado_txt": "ESTAVEL", "alarme": 0, "led_verde": 1, "led_amarelo": 0,
 "led_vermelho": 0, "dht_ok": 1, "dht_erros": 2, "heartbeat": 412, "uptime": 413,
 "oled": ["CAMARA CLIMATICA", "T: 35.1C UR: 38.4%", "SP: 35.0C REM PI", "..."]}
```

## 6. Mapas dos protocolos industriais

### Modbus (TCP e RTU): unit 1, endereços base 0

| Tabela | End. | Variável | Formato |
|---|---|---|---|
| Coil (FC1/5) | 0 | habilitado | bit, gravável |
| Coil | 1 | falha_dht (sim.) | bit, gravável |
| Discrete input (FC2) | 0–4 | led_verde, led_amarelo, led_vermelho, dht_ok, alarme ativo | bits |
| Holding (FC3/6/16) | 0 | habilitado | 0/1 |
| Holding | 1 | modo | 0/1/2 |
| Holding | 2 | fonte_sp | 0 remoto, 1 pot. |
| Holding | 3 | setpoint × 10 | 350 = 35,0 °C |
| Holding | 4 / 5 | aquecedor_cmd / ventilador_cmd | % (modo manual) |
| Holding | 6 / 7 | pot_raw / falha_dht | simulação |
| Input (FC4) | 0 / 1 / 2 | temp×10 / umid×10 / sp_efetivo×10 | int16 |
| Input | 3 / 4 | aquecedor_pwm / ventilador_pwm | % |
| Input | 5 / 6 / 7 | pot_raw / estado / alarme | |
| Input | 8 | leds | bit0 verde, bit1 amarelo, bit2 vermelho |
| Input | 9 / 10 / 11 | dht_erros / heartbeat / uptime | |
| Input | 12–13 / 14–15 | temp / umid | float32 ABCD |
| Input | 16 / 17 | aquecedor_duty / ventilador_duty | 0–255 |

### S7: DB1 (acesso não otimizado), rack 0, slot 1

| Endereço | nodes7 | Tipo | Variável |
|---|---|---|---|
| DBX0.0 / 0.1 / 0.2 | `DB1,X0.0` … | BOOL | habilitado / fonte_sp / falha_dht (gravável) |
| DBW2 | `DB1,INT2` | INT | modo (gravável) |
| DBD4 | `DB1,REAL4` | REAL | setpoint (gravável) |
| DBD8 / DBD12 | `DB1,REAL8` / `REAL12` | REAL | aquecedor_cmd / ventilador_cmd (gravável) |
| DBW16 | `DB1,INT16` | INT | pot_raw simulação (gravável) |
| DBD20 / 24 / 28 | `DB1,REAL20` … | REAL | temp / umid / sp_efetivo |
| DBD32 / 36 | `DB1,REAL32` / `REAL36` | REAL | aquecedor_pwm / ventilador_pwm |
| DBW40 / 42 | `DB1,INT40` / `INT42` | INT | estado / alarme |
| DBX44.0–44.3 | `DB1,X44.0` … | BOOL | led_verde, led_amarelo, led_vermelho, dht_ok |
| DBW46 | `DB1,INT46` | INT | pot_raw (ADC) |
| DBD48 / 52 | `DB1,DINT48` / `DINT52` | DINT | heartbeat / uptime |

Imagem de processo: `IW0` = potenciômetro; `Q0.0/Q0.1/Q0.2` = LEDs; `QB2`/`QB3` = duty do
aquecedor e do ventilador.

### OPC-UA: `ns=2;s=Camara.<variável>` (URI `urn:utfpr:camara-climatica`)

```
Objects/Camara/
  Medicoes/   temp, umid (Double) · pot_raw (Int32) · sp_efetivo (Double)
  Atuadores/  aquecedor_pwm, ventilador_pwm (Double) · aquecedor_duty, ventilador_duty (Int32)
  Estado/     estado, alarme, dht_erros, heartbeat, uptime (Int32) · estado_txt, oled (String)
              led_verde, led_amarelo, led_vermelho, dht_ok (Boolean)
  Comandos/   habilitado (Boolean) · modo, fonte_sp (Int32) · setpoint,          [graváveis]
              aquecedor_cmd, ventilador_cmd (Double)
  Simulacao/  pot_raw_sim (Int32) · falha_dht (Boolean)                          [graváveis]
```

## 7. Fluxos do Node-RED (`flows.json`)

| Aba | Conteúdo |
|---|---|
| **Câmara - Dashboard** | Dashboard 2.0 em `/dashboard/camara`: medidores, gráficos, LEDs, réplica do OLED, comandos e simulação |
| **Câmara - Banco SQLite** | tabela `camara_dados`, gravação a cada 10 s (INSERT preparado), consultas prontas, histórico no dashboard |
| **Câmara - Controle Node-RED** | controlador externo de exemplo (ON/OFF + ventilador P) que coloca o ESP32 em MANUAL |
| **Câmara - Modbus / S7 / OPC-UA** | leitura pelos 5 caminhos industriais, republicada em `camara/esp32-01/via/<protocolo>`, e escritas de setpoint/modo |

Os fluxos são gerados por `gerar_flows.py` (`python gerar_flows.py ../flows.json`).
Edite o script se quiser regenerar os fluxos com outro tópico base ou outros hosts.

## 8. Sugestões de atividades

1. Comparar ON/OFF × PI × controlador do Node-RED: use a consulta "Erro médio |SP − T| por modo" no SQLite.
2. Escrever o próprio controlador na aba "Controle Node-RED" (P, PI, PID, fuzzy) e avaliar o sobressinal.
3. Ligar o ventilador e observar a queda de temperatura **e** de umidade. Aquecer e ver a UR cair.
4. Provocar o alarme: modo MANUAL, aquecedor a 100 % e ventilador a 0 %. Depois, injetar a falha do DHT22.
5. Ler a mesma variável por MQTT, Modbus, S7 e OPC-UA. Comparar a latência e o formato (int×10, float32, REAL).
6. Desligar o simulador (`docker stop camara-sim`) e ver o *Last Will* `offline` no dashboard.

## 9. Armadilhas comuns

- Em `node-red-contrib-modbus`, o tipo "RTU-BUFFERED" envia **Modbus TCP**. Para enviar quadros RTU crus pela rede, use **TELNET**.
- O float32 segue a ordem ABCD. Muitos equipamentos usam CDAB; se aparecer um valor absurdo, inverta os registradores.
- `setpoint` no Modbus é °C × 10, porque um registrador só guarda inteiro de 16 bits.
- S7-1200/1500 reais exigem *PUT/GET* habilitado e o DB com acesso não otimizado.
- O índice de namespace OPC-UA pode mudar; em código robusto, resolva-o pelo URI.
- O DHT22 não deve ser lido mais de uma vez a cada 2 s. O simulador respeita isso.

## 10. Rodar sem Docker

```bash
pip install -r requirements.txt
python camara_sim.py --mqtt-host localhost --modbus-tcp-port 5020 --s7-port 1102 --speed 5
python testar_clientes.py --host localhost --s7-port 1102     # escreve/lê em todos os protocolos
```

Modbus RTU em serial real ou virtual: `--modbus-serial /dev/ttyUSB0 --baudrate 9600`. No
Linux, crie um par virtual com `socat -d -d pty,raw,echo=0,link=/tmp/ttyV0 pty,raw,echo=0,link=/tmp/ttyV1`;
no Windows, use o com0com. Todas as opções aparecem em `python camara_sim.py --help`.

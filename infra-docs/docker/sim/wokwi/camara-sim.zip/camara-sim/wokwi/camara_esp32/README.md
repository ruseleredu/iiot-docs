# Câmara Climática ESP32 no Wokwi

Firmware do ESP32 da câmara climática. Ele usa o **mesmo contrato MQTT** do `camara-sim`:
o dashboard, o SQLite, o controle externo e o ntfy do Node-RED do grupo funcionam sem
mudança. O mesmo sketch roda no Wokwi e na placa real.

| Arquivo | Para quê |
|---|---|
| `camara_esp32.ino` | firmware (no wokwi.com, cole como `sketch.ino`) |
| `diagram.json` | circuito: ESP32, DHT22, OLED, potenciômetro, 5 LEDs, botão, chave, analisador lógico |
| `libraries.txt` | bibliotecas que o Wokwi instala |
| `wokwi.toml` | configuração para o Wokwi no VS Code |

## Circuito

| Componente | ESP32 | No Wokwi |
|---|---|---|
| DHT22 | GPIO4 | clique no sensor: sliders de temperatura e umidade |
| Potenciômetro | GPIO34 (ADC 12 bits) | gire o knob; vira setpoint 20–55 °C com `fonte_sp = 1` |
| OLED SSD1306 | SDA GPIO21 / SCL GPIO22 | mostra a mesma tela do simulador |
| Aquecedor (PWM, LEDC 8 bits, 1 kHz) | GPIO25 | LED laranja: o brilho acompanha o PWM |
| Ventilador (PWM, LEDC 8 bits, 25 kHz) | GPIO26 | LED azul |
| LEDs verde, amarelo e vermelho | GPIO16, 17 e 5 | estável · aquecendo/resfriando · alarme |
| Botão "habilitado" | GPIO14 (pull-up) | liga e desliga a câmara |
| Chave "planta" | GPIO27 (pull-up) | **esquerda = planta virtual** · direita = DHT22 real |
| Analisador lógico | D0 = GPIO25, D1 = GPIO26 | ao parar a simulação, baixa `camara-pwm.vcd` (PulseView) |

## Planta virtual

No Wokwi o aquecedor não esquenta o DHT22. Com a **chave à esquerda**, o ESP32 roda o modelo
térmico e de umidade do `camara-sim` a partir dos PWMs que ele mesmo aplica, e a malha de
controle se fecha. O DHT22 passa a ser o **ambiente**. Mexa no slider de temperatura e veja
a câmara reagir. O cálculo usa o relógio da simulação, então a dinâmica segue correta mesmo
que o Wokwi rode abaixo de 100 % da velocidade.

Com a chave à direita (ou na placa real sem a chave), a temperatura e a umidade vêm direto
do DHT22. Também dá para trocar por MQTT: `…/cmd/planta_virtual` ← `true` ou `false`.

## Rodar

### 1. wokwi.com, no navegador (grátis)

1. Crie um projeto **ESP32** no wokwi.com.
2. Cole `camara_esp32.ino` em `sketch.ino` e substitua o `diagram.json`.
3. Crie o arquivo `libraries.txt` (Library Manager → *+* → ou cole este arquivo).
4. No topo do sketch, ajuste `GRUPO`.
5. O gateway gratuito só sai para a internet. Use um **broker público**
   (`#define MQTT_HOST "broker.hivemq.com"`) e acompanhe com MQTTX ou MQTT Explorer nesse
   broker. Atenção: num broker público, qualquer pessoa vê e pode comandar os tópicos.

### 2. wokwi.com + gateway privado (plano pago): integrado ao kit do grupo

1. Suba o kit do grupo no PC (`docker compose up -d`).
2. Rode o **Wokwi IoT Gateway** no PC e, no editor do Wokwi, pressione F1 →
   *Enable Private Wokwi IoT Gateway*.
3. Deixe `MQTT_HOST "host.wokwi.internal"`, que é o mosquitto do kit no seu PC.
4. Importe os fluxos (`py gerar_flows.py --grupo lab05-a` na raiz do `camara-sim`) e abra
   `/lab05-a/dashboard/camara`. A ponte do kit leva `lab05-a/#` até o laboratório.

> Não rode o `camara-sim` com o mesmo `GRUPO` ao mesmo tempo: os dois publicariam nos mesmos
> tópicos. Use `--sem-mqtt` no `camara-sim` se ainda quiser os servidores Modbus, S7 e OPC-UA.

### 3. VS Code (extensão Wokwi)

```bash
arduino-cli core install esp32:esp32
arduino-cli lib install PubSubClient ArduinoJson "DHT sensor library for ESPx" "Adafruit SSD1306" "Adafruit GFX Library"
arduino-cli compile --fqbn esp32:esp32:esp32 --output-dir build .
```

Depois, F1 → *Wokwi: Start Simulator* (usa `wokwi.toml` e `diagram.json`).

## Placa real

1. Ajuste `WIFI_SSID`, `WIFI_PASS`, `WIFI_CANAL 0` e `MQTT_HOST`: o IP do servidor do
   laboratório, ou o do PC com o kit.
2. Ligue o aquecedor e o ventilador por **MOSFETs logic-level** (nunca direto no GPIO) e deixe
   o GPIO27 sem nada: o modo fica "planta real".
3. Grave pela Arduino IDE (core ESP32 3.x) com as bibliotecas do `libraries.txt`.

## Contrato MQTT (resumo)

Base `<GRUPO>/camara`: `status` (online/offline, LWT), `telemetria` (JSON a cada 2 s), `oled`,
`cmd` (JSON parcial) e `cmd/<campo>`. Os campos são os mesmos do `camara-sim`, mais
`planta_virtual` e `origem: "esp32"`. O comando `pot_raw` é ignorado, porque aqui o
potenciômetro é físico: gire o knob.
